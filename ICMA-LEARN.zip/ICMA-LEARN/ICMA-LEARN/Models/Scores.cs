﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICMA_LEARN.Models
{
    public class Scores
    {
        public int UserID { get; set; }
        public int CourseCategoryID { get; set; }
        public int CourseID { get; set; }
        public int Score { get; set; }
    }
}
