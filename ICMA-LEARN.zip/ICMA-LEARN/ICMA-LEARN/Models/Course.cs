﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICMA_LEARN.Models
{
    public class Course
    {
        public int  CourseID { get; set; }
        public string CousreName { get; set; }
        public int CourseCategoryID { get; set; }
        public string CourseContent {  get; set; }
        public int CreatedBy { get; set; }
        public int courseCount { get; set; }
        public byte []CourseCoverImage { get; set; }
        public int UserID { get; set; }
    }
}
