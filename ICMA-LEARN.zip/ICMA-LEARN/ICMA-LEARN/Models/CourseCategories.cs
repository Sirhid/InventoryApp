﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICMA_LEARN.Models
{
    public class CourseCategories
    {
        public int CourseCategoryID { get; set; }
        public string CourseCategoryName { get; set; }
        public DateTime DateCreated { get; set; }
        public int CreatedBy { get; set; }

    }
}
