﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ICMA_LEARN.Security;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ICMA_LEARN .CommonClasses
{
    public class BindingLists
    {
        private long _companyId => SimpleSessionPersister.CompanyId;
        private long _userId => SimpleSessionPersister.Id;
     
      
        public List<Years> BindYear()
        {
            int startYear = 2020;
            List<Years> yrs = new List<Years>();
            for (var i=startYear; i<= DateTime.Now.Year + 1; i++)
            {
                var yr = new Years { YearId = i, YearValue = i };
                yrs.Add(yr);
            }
            
            return yrs;
        }
        public class Years
        {
            public int YearId { get; set; }
            public int YearValue { get; set; }
        }
    }
}

