﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.AspNetCore.Hosting;

namespace ICMA_LEARN.CommonClasses
{

    public static class GeneralCodes
    {
        private static IHostingEnvironment _env;
        public static string GenerateRandomString(int len, bool upper)
        {
            Random rand = new Random();
            char[] allowableChars = "abcdefghijklmnopqrstuvwxyz0123456789".ToCharArray();
            string final = string.Empty;
            for (int i = 0; i <= len - 1; i++)
            {
                final += allowableChars[rand.Next(allowableChars.Length - 1)];
            }               
            return upper ? final.ToUpper() : final;
        }

        public static string GenerateSHA256String(string inputString)
        {
            SHA256 sha256 = SHA256Managed.Create();
            byte[] bytes = Encoding.UTF8.GetBytes(inputString);
            byte[] hash = sha256.ComputeHash(bytes);
            StringBuilder stringBuilder = new StringBuilder();

            for (int i = 0; i <= hash.Length - 1; i++)
                stringBuilder.Append(hash[i].ToString("X2"));
            return stringBuilder.ToString();
        }

        public static void WriteLog(string rootPath, string msg)
        {
            try
            {
                var folderPath = $"{rootPath}/Logs";
                if (!Directory.Exists(folderPath))
                    Directory.CreateDirectory(folderPath);
                string filepath = $"{folderPath}/ErrorLog.txt";
                using (StreamWriter writer = new StreamWriter(filepath, true))
                {
                    writer.WriteLine(msg + " " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString());
                    writer.Close();
                }
            }
            catch (Exception ex)
            {

            }
        }
    }


    public class LoggedInUser
    {
        public string Fullname { get; set; }
        public string Email { get; set; }
        public string ReportingLine1 { get; set; }
        public string ReportingLine2 { get; set; }

        public string MyReportingLine1 { get; set; }
        public string MyReportingLine2 { get; set; }

        public long CompanyId { get; set; }
        public long UserId { get; set; }
        public long? RoleId { get; set; }
        public string RoleName { get; set; }
        public string HRTag { get; set; }

        public List<SitePage> UserPages { get; set; }
        //public List<NotificationVM> notifications { get; set; }
    }

    public class SitePage
    {
        public string PageDisplayName { get; set; }
        public string PageName { get; set; }
        public string FolderName { get; set; }
    }

    public class SitePagesByFolder
    {
        public List<SitePage> Pages { get; set; }
        public string FolderName { get; set; }
        //public OathofSecrecyVM oathofSecrecyVM { get; set; }
        //public AffirmationVM affirmationVM { get; set; }

    }   


    public class ReadConnectionString
    {
        public string ConnectionString { get; set; }
        public string TestConnectionString { get; set; }
    }

    public class ReadSMTPSettings
    {
        public string SmtpServer { get; set; }
        public string SenderAddress { get; set; }
        public string DisplayName { get; set; }
        public int SmtpPort { get; set; }
    }

    public enum ACTION
    {
        INSERT = 1,
        SLECT=2,
        UPDATE=3,
        DELETE=4,
        SELECTSINGLE=5
    }

    public enum STATUS
    {
        Success = 1,
        Warning,
        Error,
        Info
    }

    public enum LoadEmployeeBy
    {
        EmployeeId = 1,
        HrTag = 2,
        PhoneNumber = 3,
        EmailAddy = 4
    }
    public enum approvalRank
    {
        HR=1,
        Financeofficer = 2,
        DirFinance = 3,
        PensionOfficer=4,
        PensionHead = 6,
        DDHRM = 7
    }

    public enum AppraisalSequenceStatus
    {
    IsSaved =1,
    IsSubmitted =2, IsLineManger1=3, IsAgreeOrDisagree = 4, IsLineManager2 =5, IsPromotedOrNot =6
    }
    public enum TargetParticipant
    {
        Everyone =1,
        Department =2,
        Cadre =3,
        Division =4,
        Custom = 5
    }

    public static class Notify
    {
        public const string SuperAdmin = "Super Administrator";
        public const string Tester = "Tester";
        public const string SetupAdmin = "Setup Admin";
        public const string Accounts = "Accounts";
        public const string HRUser = "HR User";
        public const string HRManager = "HR Manager";
        public const string Reporter = "Reporter";
        public const string FinanceUser = "Finance User";
        public const string FinanceHead = "Finance Head";
        public const string PensionOfficer = "Pension Officer";
        public const string PensionHead = "Pension Head";

    }
    public enum SendEmailTo
    {
        SuperAdmin = 12,
        Tester = 15,
        SetupAdmin = 17,
        Accounts = 19,
        HRUser = 25,
        HRManager = 26,
        Reporter = 28,
        FinanceUser = 31,
        FinanceHead = 32,
        PensionOfficer = 35,
        PensionHead = 38,

    }

    public enum Priority
    {
        High = 1,
        Medium = 2,
        Low = 3
    }


    public static class MailTemplates
    {
        public const string General = "MailTemplates\\General.html"; 
        public const string EmploymentList = "MailTemplates\\EmploymentList.html";
        public const string Finance = "/MailTemplates/HRNotification.html";
        public const string FinanceToHr = "/MailTemplates/HRNotification.html";
        public const string ForgotPassword = "/MailTemplates/HRNotification.html";
        public const string HeadHr = "/MailTemplates/HRNotification.html";
        public const string HR = "/MailTemplates/HRNotification.html";
        public const string recallemail = "/MailTemplates/HRNotification.html";
        public const string pension = "/MailTemplates/PensionTemplate.html";

    }
}
