﻿using ICMA_LEARN.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICMA_LEARN.Data.IRepository
{
     public interface IScore
    {
        Task<List<User>> GetScores();

    }
}
