﻿using ICMA_LEARN.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ICMA_LEARN.Data.IRepository
{
   public  interface ICourses 
    {
        //Task<Course > AddCourse(Course course);
        int AddCourse(Course course);

    }
}
