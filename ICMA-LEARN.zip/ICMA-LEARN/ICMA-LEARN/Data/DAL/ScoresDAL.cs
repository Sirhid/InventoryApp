﻿using AutoMapper;
using Dapper;
using ICMA_LEARN.CommonClasses;
using ICMA_LEARN.Data.IRepository;
using ICMA_LEARN.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ICMA_LEARN.Data.DAL
{
    public class ScoresDAL :IScore
    {
        private string conString;
        IOptions<ReadConnectionString> _ConnectionString;
        public ScoresDAL(IOptions<ReadConnectionString> ConnectionString)
        {
            _ConnectionString = ConnectionString;
            conString = _ConnectionString.Value.ConnectionString;
        }
      
        Task<List<Models.User>> IScore.GetScores()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Action", 2);
                    dynamic ret = con.Query<dynamic>("sp_Course", param: param, commandType: CommandType.StoredProcedure).ToList();
                    var datatoreturn = JsonConvert.DeserializeObject<Models.Scores>(JsonConvert.SerializeObject(ret));
                    return datatoreturn;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //return null;
        }
    }
}
