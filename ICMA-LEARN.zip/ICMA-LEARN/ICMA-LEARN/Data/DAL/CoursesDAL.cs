﻿using AutoMapper;
using ICMA_LEARN.Data.IRepository;
using ICMA_LEARN.Models;
using System;
using System.Collections.Generic;
using Microsoft.Extensions.Options;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using ICMA_LEARN.CommonClasses;
using Dapper;

namespace ICMA_LEARN.Data.DAL
{
   
    public class CoursesDAL : ICourses 
    {
        private string conString;
        IOptions<ReadConnectionString> _ConnectionString;

        public CoursesDAL (IOptions<ReadConnectionString> ConnectionString)
        {
        }
       
        public  int AddCourse(Course course)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var param = new DynamicParameters();
                    param.Add("@CousreName", course.CousreName );
                    param.Add("@CourseContent", course.CourseContent);
                    param.Add("@CourseCoverImage", course.CourseCoverImage);
                    param.Add("@CourseCategoryID", course.CourseCategoryID );
                    dynamic ret = con.Execute("Sp_Users", param: param, commandType: CommandType.StoredProcedure);
                    return ret;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
           
        }
    }
