﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ICMA_LEARN.Data.IRepository;
using ICMA_LEARN.Enum;
using ICMA_LEARN.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace ICMA_LEARN.Controllers
{
    public class ScoreController : Controller
    {
        private readonly IScore _score ;

        public ScoreController(IScore score)
        {
            _score = score;
        }

        public async Task <IActionResult>GetScores()
        {
            var scores  = new List<User>();

            try
            {
                scores =  await _score.GetScores();

                if (TempData["Status"] != null)
                {
                    ViewBag.Message = TempData["Message"].ToString();
                    ViewBag.Status = TempData["Status"].ToString();
                }
                return View(scores);
            }
            catch (Exception ex)
            {
              
                return View(scores);
            }
        }
    }
}