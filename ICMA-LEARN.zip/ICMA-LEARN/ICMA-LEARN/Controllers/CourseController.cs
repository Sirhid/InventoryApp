﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ICMA_LEARN.Data.IRepository;
using ICMA_LEARN.Enum;
using ICMA_LEARN.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ICMA_LEARN.Controllers
{
    public class CourseController : Controller
    {
        private readonly ICourses _course;
        public CourseController(ICourses course)
        {
            _course = course;
        }
        public IActionResult Course()
        {

            try
            {
                return View(new Course
                {

                });


            }
            catch (Exception ex)
            {             
                return View(new Course 
                {             
                });
            }
        }
        //public async Task <IActionResult> Course(IFormFile files, Course Fd)
        //{
        //    try
        //    {
        //        var file = Request.Form.Files;

        //        String FileExt = Path.GetExtension(file[0].FileName).ToUpper();

        //        if (FileExt == ".PDF" || FileExt == ".DOCX" || FileExt == ".TXT" || FileExt == ".PPT" || FileExt == ".DOTX" || FileExt == ".ODT")
        //        {
        //            Stream str = file[0].OpenReadStream();
        //            BinaryReader Br = new BinaryReader(str);
        //            Byte[] FileDet = Br.ReadBytes((int)str.Length);
        //            Fd.CousreName  = file[0].FileName;
        //            Fd.CourseCoverImage   = FileDet;
        //            var res =  _course.AddCourse(Fd);
        //            if (res > 0)
        //            {
        //                TempData["Message"] = "You have Uploaded" + Fd.CousreName + " " + "Successfully";
        //                return RedirectToAction("Index");
        //            }
                   
        //            else
        //            {
        //                ViewBag.Message = "Course Failed to Upload";
        //            }
        //        }
        //        else
        //        {
        //            ViewBag.FileStatus = "Invalid file format.";
        //            ViewBag.Message = "Invalid file format.";
        //            return View(Fd);

        //        }
        //        return View(Fd);

        //    }
        //    catch (Exception ex)
        //    {
        //        return View(new Course());
        //    }


        //}

    }
}