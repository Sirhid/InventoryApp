﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibmotInventory.Models
{
    public class Login
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public bool RememberMe { get; set; }
        public string RedirectUrl { get; set; }
    }

    public class ChangePassword
    {
        public string Username { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
        public string ConfirmNewPassword { get; set; }
        public long EmployeeId { get; set; }
        public object CreatedBy { get; internal set; }
        public object CompanyId { get; set; }
    }
    public class ChangePasswordVM
    {
        //public string OldPassword { get; set; }
        public string NewPassword { get; set; }
        public string ConfirmNewPassword { get; set; }
        public long EmployeeId { get; set; }
        public long CreatedBy { get; set; }
        public long CompanyId { get; set; }
    }

    public class ForgotPassword
    {
        public string UserName { get; set; }
    }
}
