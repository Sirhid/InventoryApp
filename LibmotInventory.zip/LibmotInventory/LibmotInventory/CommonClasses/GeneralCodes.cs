﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using LibmotInventory.ViewModels;

namespace LibmotInventory.CommonClasses
{

    public static class GeneralCodes
    {
        private static IHostingEnvironment _env;
        public static string GenerateRandomString(int len, bool upper)
        {
            Random rand = new Random();
            char[] allowableChars = "abcdefghijklmnopqrstuvwxyz0123456789".ToCharArray();
            string final = string.Empty;
            for (int i = 0; i <= len - 1; i++)
            {
                final += allowableChars[rand.Next(allowableChars.Length - 1)];
            }
            return upper ? final.ToUpper() : final;
        }

        public static string GenerateSHA256String(string inputString)
        {
            SHA256 sha256 = SHA256Managed.Create();
            byte[] bytes = Encoding.UTF8.GetBytes(inputString);
            byte[] hash = sha256.ComputeHash(bytes);
            StringBuilder stringBuilder = new StringBuilder();

            for (int i = 0; i <= hash.Length - 1; i++)
                stringBuilder.Append(hash[i].ToString("X2"));
            return stringBuilder.ToString();
        }
    }

    public class ReadConnectionString
    {
        public string ConnectionString { get; set; }
        public string TestConnectionString { get; set; }
    }

    public enum ACTION
    {
        INSERT = 1,
        SLECT=2,
        UPDATE=3,
        DELETE=4,
        SELECTSINGLE=5
    }

    public enum STATUS
    {
        Success = 1,
        Warning,
        Error,
        Info
    }


    public class LoggedInUser
    {
        public string Email { get; set; }

        public long EmployeeID { get; set; }

    }
}
