﻿using Dapper;
using LibmotInventory.CommonClasses;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace LibmotInventory.Infrastructure.Repository
{
    public class ItemDAL : IItemDAL
    {
        IOptions<ReadConnectionString> _ConnectionString;
        private string conString;
        public ItemDAL(IOptions<ReadConnectionString> ConnectionString)
        {
            _ConnectionString = ConnectionString;
            conString = _ConnectionString.Value.ConnectionString;
        }


        public T LoadAllItems<T>()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Action", 3);
                    dynamic ret = con.Query<dynamic>("Sp_Items", param: param, commandType: CommandType.StoredProcedure).ToList();
                    var datatoreturn = JsonConvert.DeserializeObject<T>(JsonConvert.SerializeObject(ret));
                    return datatoreturn;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public T LoadAllItemsByID<T>(long ItemID)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Action", 4);
                    param.Add("@ItemID", ItemID);
                    dynamic ret = con.Query<dynamic>("Sp_Items", param: param, commandType: CommandType.StoredProcedure).SingleOrDefault();
                    var datatoreturn = JsonConvert.DeserializeObject<T>(JsonConvert.SerializeObject(ret));
                    return datatoreturn;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int InsertItem(string ItemName, string ItemDescription, int ItemQuantity, int WareHouseID, int CreatedBy)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Action", 1);
                    param.Add("@ItemName", ItemName);
                    param.Add("@ItemDescription", ItemDescription);
                    param.Add("@ItemQuantity", ItemQuantity);
                    param.Add("@WareHouseID", WareHouseID);
                    param.Add("@CreatedBy", CreatedBy);
                    int ret = con.Execute("Sp_Items", param: param, commandType: CommandType.StoredProcedure);
                    return ret;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int UpdateItem(string ItemName, string ItemDescription, int ItemQuantity, int WareHouseID, int ItemID)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Action", 4);
                    param.Add("@ItemName", ItemName);
                    param.Add("@ItemDescription", ItemDescription);
                    param.Add("@ItemQuantity", ItemQuantity);
                    param.Add("@WareHouseID", WareHouseID);
                    param.Add("@ItemID", ItemID);
                    int ret = con.Execute("Sp_Items", param: param, commandType: CommandType.StoredProcedure);
                    return ret;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int DeleteItem(int ItemID)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Action", 5);
                    param.Add("@ItemID", ItemID);
                    int ret = con.Execute("Sp_Items", param: param, commandType: CommandType.StoredProcedure);
                    return ret;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }



}
