﻿using Dapper;
using LibmotInventory.CommonClasses;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace LibmotInventory.Infrastructure.Repository
{
    public class WareHouseDAL : IWareHouseDAL
    {

        IOptions<ReadConnectionString> _ConnectionString;
        private string conString;
        public WareHouseDAL(IOptions<ReadConnectionString> ConnectionString)
        {
            _ConnectionString = ConnectionString;
            conString = _ConnectionString.Value.ConnectionString;
        }

        public T LoadWareHouse<T>()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Action", 2);
                    dynamic ret = con.Query<dynamic>("Sp_WareHouse", param: param, commandType: CommandType.StoredProcedure).ToList();
                    var datatoreturn = JsonConvert.DeserializeObject<T>(JsonConvert.SerializeObject(ret));
                    return datatoreturn;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public T LoadWareHouseByID<T>(long WareHouseID)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Action", 3);
                    param.Add("@WareHouseID", WareHouseID);
                    dynamic ret = con.Query<dynamic>("Sp_WareHouse", param: param, commandType: CommandType.StoredProcedure).SingleOrDefault();
                    var datatoreturn = JsonConvert.DeserializeObject<T>(JsonConvert.SerializeObject(ret));
                    return datatoreturn;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int InsertWareHouse(string WareHouseName, string WareHouseDescription, string WareHouseAddress, int CreatedBy)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Action", 1);
                    param.Add("@WareHouseName", WareHouseName);
                    param.Add("@WareHouseDescription", WareHouseDescription);
                    param.Add("@WareHouseAddress", WareHouseAddress);
                    param.Add("@CreatedBy", CreatedBy);
                    int ret = con.Execute("Sp_WareHouse", param: param, commandType: CommandType.StoredProcedure);
                    return ret;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int UpdateWareHouse(long WareHouseID, string WareHouseName, string WareHouseDescription, string WareHouseAddress)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Action", 4);
                    param.Add("@WareHouseID", WareHouseID);
                    param.Add("@WareHouseName", WareHouseName);
                    param.Add("@WareHouseDescription", WareHouseDescription);
                    param.Add("@WareHouseAddress", WareHouseAddress);
                    int ret = con.Execute("Sp_WareHouse", param: param, commandType: CommandType.StoredProcedure);
                    return ret;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int DeleteWareHouse(int WareHouseNameID)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Action", 5);
                    param.Add("@WareHouseNameID", WareHouseNameID);
                    int ret = con.Execute("Sp_WareHouse", param: param, commandType: CommandType.StoredProcedure);
                    return ret;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
