﻿using Dapper;
using LibmotInventory.CommonClasses;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace LibmotInventory.Infrastructure.Repository
{
    public class EmployeeDAL
    {
        IOptions<ReadConnectionString> _ConnectionString;
        private string conString;
        public EmployeeDAL(IOptions<ReadConnectionString> ConnectionString)
        {
            _ConnectionString = ConnectionString;
            conString = _ConnectionString.Value.ConnectionString;
        }

        public T LoadAllEmployees<T>()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Action", 3);
                    dynamic ret = con.Query<dynamic>("Sp_Employee", param: param, commandType: CommandType.StoredProcedure).ToList();
                    var datatoreturn = JsonConvert.DeserializeObject<T>(JsonConvert.SerializeObject(ret));
                    return datatoreturn;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public int InsertEmployee(string FirstName, string LastName, string  Email, string  PhoneNumber, int CreatedBy)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Action", 1);
                    param.Add("@FirstName", FirstName);
                    param.Add("@LastName", LastName);
                    param.Add("@Email", Email);
                    param.Add("@PhoneNumber", PhoneNumber);
                    param.Add("@CreatedBy", CreatedBy);
                    int ret = con.Execute("Sp_Employee", param: param, commandType: CommandType.StoredProcedure);
                    return ret;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
