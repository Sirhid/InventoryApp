﻿using Dapper;
using LibmotInventory.CommonClasses;
using LibmotInventory.Infrastructure;
using LibmotInventory.Models;
using LibmotInventory.CommonClasses;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using LibmotInventory.Infrastructure.IRepository;

namespace HRIS.Infrastructure.Repository
{
    public class UserManagement : IUserManagement
    {
        IOptions<ReadConnectionString> _ConnectionString;
        private string conString;
        public UserManagement(IOptions<ReadConnectionString> ConnectionString)
        {
            _ConnectionString = ConnectionString;
            conString = _ConnectionString.Value.ConnectionString;
        }

        public dynamic Login(string email, string password)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    var encryptPassword = GeneralCodes.GenerateSHA256String(password);
                    var param = new DynamicParameters();
                    param.Add("@Email", email);
                    param.Add("@Password", encryptPassword);
                    SqlMapper.GridReader ret = SqlMapper.QueryMultiple(con, "sp_USM_Login_Users", param: param, commandType: CommandType.StoredProcedure);

                    dynamic user = ret.ReadFirstOrDefault<dynamic>();
                       if (user != null)
                    {
                        bool oldpassword = ret.ReadFirstOrDefault<bool>();
                        return new
                        {
                            User = user,
                            IsOldPassword = oldpassword
                        };
                    }
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

     
      
    }
}
