﻿using LibmotInventory.Models;

namespace LibmotInventory.Infrastructure.IRepository
{
    public interface IUserManagement
    {
     
        dynamic Login(string email, string password);

     
    }
}