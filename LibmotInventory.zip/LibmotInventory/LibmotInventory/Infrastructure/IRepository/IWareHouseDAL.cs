﻿namespace LibmotInventory.Infrastructure.Repository
{
    public interface IWareHouseDAL
    {
        int DeleteWareHouse(int WareHouseNameID);
        int InsertWareHouse(string WareHouseName, string WareHouseDescription, string WareHouseAddress, int CreatedBy);
        T LoadWareHouse<T>();
        T LoadWareHouseByID<T>(long WareHouseID);
        int UpdateWareHouse(long WareHouseID, string WareHouseName, string WareHouseDescription, string WareHouseAddress);
    }
}