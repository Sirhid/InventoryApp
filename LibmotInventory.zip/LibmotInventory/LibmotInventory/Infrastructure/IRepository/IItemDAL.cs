﻿namespace LibmotInventory.Infrastructure.Repository
{
    public interface IItemDAL
    {
        int DeleteItem(int ItemID);
        int InsertItem(string ItemName, string ItemDescription, int ItemQuantity, int WareHouseID, int CreatedBy);
        T LoadAllItems<T>();
        T LoadAllItemsByID<T>(long ItemID);
        int UpdateItem(string ItemName, string ItemDescription, int ItemQuantity, int WareHouseID, int ItemID);
    }
}