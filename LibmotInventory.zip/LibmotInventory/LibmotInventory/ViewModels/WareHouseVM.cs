﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibmotInventory.ViewModels
{
    public class WareHouseVM
    {
        public int WareHouseID { get; set; }
        public string WareHouseName { get; set; }
        public string WareHouseDescription { get; set; }
        public string WareHouseAddress { get; set; }
        public int isDeleted { get; set; }
        public int CreatedBy { get; set; }
        public DateTime DateModified { get; set; }
        public DateTime DateCreated { get; set; }

    }
}
