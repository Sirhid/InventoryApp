﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibmotInventory.ViewModels
{
    public class ItemsVM
    {
        public int ItemID { get; set; }
        public string ItemName { get; set; }
        public string ItemDescription { get; set; }
        public int WareHouseID { get; set; }
        public int ItemQuantity { get; set; }
        public int isDeleted { get; set; }
        public int CreatedBy { get; set; }
        public string WareHouseName { get; set; }
        public List<WareHouseVM> WareHouses { get; set; }
        public DateTime DateModified { get; set; }
        public DateTime DateCreated { get; set; }

    }
}
