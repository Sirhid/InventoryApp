﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibmotInventory.ViewModels
{
    public class EmployeeVM
    {
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public int isDeleted { get; set; }
        public int CreatedBy { get; set; }
        public  DateTime DateModified { get; set; }
        public DateTime DateCreated { get; set; }

    }
}
