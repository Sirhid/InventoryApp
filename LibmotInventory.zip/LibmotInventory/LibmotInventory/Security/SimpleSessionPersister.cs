﻿using LibmotInventory.CommonClasses;
using LibmotInventory.Converters;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace LibmotInventory.Security
{
    public static class SimpleSessionPersister
    {
        private static IHttpContextAccessor _httpContextAccessor => new HttpContextAccessor();
        #region IsAuthenticated
        public static bool IsAuthenticated
        {
            get
            {
                if (_httpContextAccessor.HttpContext.Session.GetString("Account") != null && _httpContextAccessor.HttpContext.Session.GetString("LoggedInUser") != null)
                {
                    return true;
                }
                return false;
            }
        }

        public static LoggedInUser LoggedUserDetails
        {
            get
            {
                try
                {
                    if (_httpContextAccessor.HttpContext.Session != null)
                        return JsonConvert.DeserializeObject<LoggedInUser>(_httpContextAccessor.HttpContext.Session.GetString("LoggedInUser"));

                    return null;
                }
                catch (Exception ex)
                {             
                    throw ex;
                }
            }
        }
        #endregion

        #region Profile Fields
        

        public static long EmployeeId
        {
            get { return GetClaimInt64(ClaimTypes.NameIdentifier); }
        }

        public static string Email
        {
            get { return GetClaim(ClaimTypes.Email); }
        }
       
        #endregion

        //Get Claims
        private static int GetClaimInt32(string claimType)
        {
            return int.Parse(GetClaim(claimType) ?? "0");
        }

        private static long GetClaimInt64(string claimType)
        {
            return long.Parse(GetClaim(claimType) ?? "0");
        }


        public static string GetClaim(string claimType)
        {
            string acctString = _httpContextAccessor.HttpContext.Session.GetString("Account");
            if (acctString != null)
            {                
                var acc = JsonConvert.DeserializeObject<List<Claim>>(acctString,new ClaimsConverter());
                if (acc != null)
                {
                    var claim = acc.FirstOrDefault(c => c.Type == claimType);
                    if (claim != null)
                        return claim.Value;
                }
            }
            return null;
        }

        public static void SetAuthentication(LoggedInUser acc)
        {
            if (acc.EmployeeID == 0)
                throw new ArgumentNullException("EmployeeID");
            if (string.IsNullOrEmpty(acc.Email))
                throw new ArgumentNullException("Email");
         
            //create claim basic.
            var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Email , acc.Email.ToString()),
                    new Claim(EmployeeId.ToString(), acc.EmployeeID.ToString()),
                    
                };
            

            _httpContextAccessor.HttpContext.Session.SetString("Account", JsonConvert.SerializeObject(claims));
            _httpContextAccessor.HttpContext.Session.SetString("LoggedInUser", JsonConvert.SerializeObject(acc));
             
        }

        public static void SignOut()
        {
            _httpContextAccessor.HttpContext.Session.Remove("Account"); //  .SetString("Account", null) ;
            _httpContextAccessor.HttpContext.Session.Remove("LoggedInUser"); 
        }
    }
}
