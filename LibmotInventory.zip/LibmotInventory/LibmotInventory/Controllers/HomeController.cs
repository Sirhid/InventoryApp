﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using LibmotInventory.Models;
using LibmotInventory.ViewModels;
using LibmotInventory.Infrastructure.Repository;
using LibmotInventory.CommonClasses;

namespace LibmotInventory.Controllers
{
    public class HomeController : Controller
    {
        private IItemDAL _itemDAL;
        private IWareHouseDAL _wareHouseDAL;
        public HomeController(IItemDAL itemDAL, IWareHouseDAL wareHouseDAL)
        {
            _itemDAL = itemDAL;
            _wareHouseDAL = wareHouseDAL;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        //public IActionResult Items()
        //{
        //    var ItemResponse = new List<ItemsVM>();

        //    try
        //    {
        //        ItemResponse = _itemDAL.LoadAllItems<List<ItemsVM>>();

        //        if (TempData["Status"] != null)
        //        {
        //            ViewBag.Message = TempData["Message"].ToString();
        //            ViewBag.Status = TempData["Status"].ToString();
        //        }
        //        return View(ItemResponse);
        //    }
        //    catch (Exception ex)
        //    {
        //        ViewBag.Message = "An error occured";
        //        ViewBag.Status = STATUS.Error;
        //        return View(ItemResponse);
        //    }
        //}
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
