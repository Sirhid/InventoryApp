﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using LibmotInventory.Infrastructure.Repository;
using LibmotInventory.ViewModels;
using System.Web;
using LibmotInventory.Infrastructure.IRepository;
using LibmotInventory.CommonClasses;
using LibmotInventory.Models;
using LibmotInventory.Security;

namespace HRIS.Controllers
{
    public class AccountController : Controller
    {
        private IUserManagement _account;
        private IConfiguration _config;
        private IHostingEnvironment _env;
        private readonly string clientUrl;
        public AccountController(IUserManagement account,IConfiguration config, IHostingEnvironment env)
        {
            _account = account;
            _config = config;
            _env = env;
            clientUrl = _config.GetValue<string>("webUrl");
        }
      

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Login(Login login)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    ViewBag.Message = "Enter your Email and password";
                    ViewBag.Status = 3;
                    return View("Login", login);
                }
                var response = _account.Login(login.Username, login.Password);
                if (response == null)
                {
                    ViewBag.Message = "Incorrect login credentials";
                    ViewBag.Status = 3;
                    return View("Login", login);
                }
                else
                {
                    if (response.IsOldPassword)
                    {                       
                       return  RedirectToAction("ChangePassword");
                    }
                   
                        LoggedInUser loggedUser = new LoggedInUser
                        {
                           
                            Email = response.User.EmailAddy,
                            EmployeeID= response.User.EmployeeID,
                        
                        };
                        HttpContext.Session.SetString(login.Username, login.Username);
                        SimpleSessionPersister.SetAuthentication(loggedUser);
                        if (string.IsNullOrEmpty(login.RedirectUrl))
                            return RedirectToAction("Index", "Home");
                        else
                            return Redirect(login.RedirectUrl);
                
                  
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "Error Occured "+ ex.Message;
                ViewBag.Status = STATUS.Error;
                return View("Login", login);
            }
        }

      

        public IActionResult TestConnection()
        {
            return View();
        }

      
        public IActionResult SignOut()
        {
            SimpleSessionPersister.SignOut();
            return RedirectToAction("Login", "Account");
        }

      

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
