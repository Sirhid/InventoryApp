﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using LibmotInventory.Models;
using LibmotInventory.ViewModels;
using LibmotInventory.CommonClasses;
using LibmotInventory.Infrastructure.Repository;

namespace LibmotInventory.Controllers
{
    public class WareHouseController : Controller
    {
        private IWareHouseDAL _wareHouseDAL;

        public WareHouseController(IWareHouseDAL wareHouseDAL)
        {
            _wareHouseDAL = wareHouseDAL;
        }

        public IActionResult WareHouse()
        {
            var WareHouse = new List<WareHouseVM>();

            try
            {
                WareHouse = _wareHouseDAL.LoadWareHouse<List<WareHouseVM>>();

                if (TempData["Status"] != null)
                {
                    ViewBag.Message = TempData["Message"].ToString();
                    ViewBag.Status = TempData["Status"].ToString();
                }
                return View(WareHouse);
            }
            catch (Exception ex)
            {
                ViewBag.Message = "An error occured";
                ViewBag.Status = STATUS.Error;
                return View(WareHouse);
            }
        }


        public IActionResult WareHouseUpdate(int WareHouseID)
        {

            try
            {
                if (WareHouseID == 0)
                {
                    return View(new WareHouseVM
                    {
                     
                    });
                }
                else 
                {
                    var WareResponse = _wareHouseDAL.LoadWareHouseByID<WareHouseVM>(WareHouseID);

                    return View(WareResponse);
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "An error occured";
                ViewBag.Status = STATUS.Error;
                return View(new WareHouseVM
                {
                });
            }
        }

        [HttpPost]
        public IActionResult WareHouseUpdate(WareHouseVM wares)
        {
            var WareHouses = _wareHouseDAL.LoadWareHouse<List<WareHouseVM>>();
            try
            {
                if (ModelState.IsValid)
                {
                    
                    if (wares.WareHouseID ==0) //Add Record
                    {
                        int result = _wareHouseDAL.InsertWareHouse(wares.WareHouseName,wares.WareHouseDescription, wares.WareHouseAddress,1);
                        if (result > 0)
                        {
                            ViewBag.Message = "WareHouse Added Successfully";
                            ViewBag.Status = STATUS.Success;
                            ViewBag.Action = "Add";
                            return RedirectToAction("WareHouse");
                          

                        }
                        else
                        {
                            ViewBag.Message = "WareHouse could not be added";
                            ViewBag.Status = STATUS.Error;
                            return View(wares);
                        }


                    }
                    else //Update new record
                    {


                        int result = _wareHouseDAL.UpdateWareHouse(wares.WareHouseID, wares.WareHouseName, wares.WareHouseDescription, wares.WareHouseAddress);
                        if (result != 0)
                        {
                            TempData["Message"] = "WareHouse Updated Successfully";
                            TempData["Status"] = STATUS.Success.ToString();
                            return RedirectToAction("WareHouse");
                        }
                        else
                        {
                            ViewBag.Message = "Updating WareHouse failed";
                            ViewBag.Status = STATUS.Error;
                            return View(wares);
                        }


                    }

                    //return View(items);
                }
                else
                {
                    ViewBag.Message = "Some required fields are empty";
                    ViewBag.Status = STATUS.Error;
                    return View(wares);
                }

            }
            catch (Exception ex)
            {
                ViewBag.Message = "An error occured";
                ViewBag.Status = STATUS.Error;
                return View(wares);
            }

        }



        public IActionResult WareHouseDelete(int WareHouseID)
        {
            ItemsVM tem = new ItemsVM();
            try
            {
                int ret = _wareHouseDAL.DeleteWareHouse(WareHouseID);
                if (ret > 0)
                    return Json(new { Status = STATUS.Success.ToString(), Message = "WareHouse deleted successfully" }); //JsonRequestBehavior.AllowGet;

                else
                    return Json(new { Status = STATUS.Error.ToString(), Message = "Error deleting Item " });
            }
            catch (Exception ex)
            {
                return Json(new { Status = STATUS.Error.ToString(), Message = "An error occured" });
            }
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
