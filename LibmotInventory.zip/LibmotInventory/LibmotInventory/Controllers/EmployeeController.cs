﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using LibmotInventory.Models;
using LibmotInventory.ViewModels;
using LibmotInventory.CommonClasses;
using LibmotInventory.Infrastructure.Repository;

namespace LibmotInventory.Controllers
{
    public class EmployeeController : Controller
    {
        private IItemDAL _itemDAL;
        private IWareHouseDAL _wareHouseDAL;

        public EmployeeController(IItemDAL itemDAL, IWareHouseDAL wareHouseDAL)
        {
            _itemDAL = itemDAL;
            _wareHouseDAL = wareHouseDAL;
        }

        public IActionResult Items()
        {
            var ItemResponse = new List<ItemsVM>();

            try
            {
                ItemResponse = _itemDAL.LoadAllItems<List<ItemsVM>>();

                if (TempData["Status"] != null)
                {
                    ViewBag.Message = TempData["Message"].ToString();
                    ViewBag.Status = TempData["Status"].ToString();
                }
                return View(ItemResponse);
            }
            catch (Exception ex)
            {
                ViewBag.Message = "An error occured";
                ViewBag.Status = STATUS.Error;
                return View(ItemResponse);
            }
        }


        public IActionResult ItemsUpdate(int ItemID, int WareHouseID)
        {

            var WareHouses = _wareHouseDAL.LoadWareHouseByID<List<WareHouseVM>>(WareHouseID);
            var WareHouse = _wareHouseDAL.LoadWareHouse<List<WareHouseVM>>();

            try
            {
                if (ItemID == 0)
                {
                    return View(new ItemsVM
                    {
                         WareHouses= WareHouse

                    });
                }
                else 
                {
                    var ItemResponse = _itemDAL.LoadAllItemsByID<ItemsVM>(ItemID);
                    ItemResponse.WareHouses = WareHouses;

                    return View(ItemResponse);
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "An error occured";
                ViewBag.Status = STATUS.Error;
                return View(new ItemsVM
                {
                     WareHouses= WareHouses
                });
            }
        }

        [HttpPost]
        public IActionResult ItemsUpdate(ItemsVM items)
        {
            var WareHouses = _wareHouseDAL.LoadWareHouse<List<WareHouseVM>>();
            var Item = new List<ItemsVM>();
            try
            {
                if (ModelState.IsValid)
                {
                    items.WareHouses = WareHouses;
                    
                    if (items.ItemID ==0) //Add Record
                    {
                        int result = _itemDAL.InsertItem(items.ItemName, items.ItemDescription,items.ItemQuantity,items.WareHouseID,1);
                        if (result > 0)
                        {
                            ViewBag.Message = "Item Added Successfully";
                            ViewBag.Status = STATUS.Success;
                            ViewBag.Action = "Add";
                            return RedirectToAction("Items");
                          

                        }
                        else
                        {
                            ViewBag.Message = "Item could not be added";
                            ViewBag.Status = STATUS.Error;
                            return View(items);
                        }


                    }
                    else //Update new record
                    {


                        int result = _itemDAL.UpdateItem(items.ItemName,items.ItemDescription,items.ItemQuantity,items.WareHouseID,items.ItemID);
                        if (result != 0)
                        {
                            TempData["Message"] = "Item Updated Successfully";
                            TempData["Status"] = STATUS.Success.ToString();
                            return RedirectToAction("Items");
                        }
                        else
                        {
                            ViewBag.Message = "Updating Item failed";
                            ViewBag.Status = STATUS.Error;
                            return View(items);
                        }


                    }

                    //return View(items);
                }
                else
                {
                    ViewBag.Message = "Some required fields are empty";
                    ViewBag.Status = STATUS.Error;
                    return View(items);
                }

            }
            catch (Exception ex)
            {
                ViewBag.Message = "An error occured";
                ViewBag.Status = STATUS.Error;
                return View(items);
            }

        }



        public IActionResult ItemsDelete(int id)
        {
            ItemsVM tem = new ItemsVM();
            try
            {
                int ret = _itemDAL.DeleteItem(id);
                if (ret > 0)
                    return Json(new { Status = STATUS.Success.ToString(), Message = "Item deleted successfully" }); //JsonRequestBehavior.AllowGet;

                else
                    return Json(new { Status = STATUS.Error.ToString(), Message = "Error deleting Item " });
            }
            catch (Exception ex)
            {
                return Json(new { Status = STATUS.Error.ToString(), Message = "An error occured" });
            }
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
