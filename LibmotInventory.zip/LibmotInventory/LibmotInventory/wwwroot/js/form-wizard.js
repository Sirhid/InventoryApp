var FormWizard = function() {
    var handleformwizard = function (){
        $('#rootwizard').bootstrapWizard({
            'tabClass': 'bwizard-steps clearfix clickable',
            'onTabShow': function (tab, navigation, index) {
                 
                var $total = navigation.find('li').length;
                var $current = index+1;
                var $percent = ($current/$total) * 100;
                $('#rootwizard').find('.progress-bar').css({ width: $percent + '%' });
                $("[id*=txtTabNo]").val($current);
                //if ($current == 9) {
                //    $("[id*=btnNext]").css("display", "none");
                //    $("[id*=btnSaveContinue]").css("display", "none");
                //}
                //else {
                //    $("[id*=btnNext]").css("display", "inline");
                //    $("[id*=btnSaveContinue]").css("display", "inline");
                //}
            },
            'onNext': function(tab, navigation, index) {
                //var $valid = $("#wizardForm").valid();
                //if(!$valid) {
                //    $validator.focusInvalid();
                //    return false;
                //}
            },
            'onTabClick': function (tab, navigation, index) {
                //var $valid = $("#wizardForm").valid();
                //if(!$valid) {
                //    $validator.focusInvalid();
                //    return false;
                //}
                // 
                //var tabX = tab;
                //var indexX = index;
                //var current_tab = $("ul.bwizard-steps li.active a").attr("href").replace("#", "");
                //var current_tabNo = $("ul.bwizard-steps li.active a").attr("href").replace("#tab", "");
                //$("[id*=TabName]").val(current_tab);
                //$("[id*=txtTabNo]").val(current_tabNo);
            },
        });		
    }	
    return {
        init: function () {
            handleformwizard();
        }
    };
}();

